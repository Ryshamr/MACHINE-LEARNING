#!/usr/bin/env python
# coding: utf-8

# In[55]:


import tensorflow as tf
from tensorflow.keras.datasets import cifar10
import matplotlib.pyplot as plt


# In[56]:


(x_train, y_train), (x_test, y_test) = cifar10.load_data()


# # Split the data into training and testing sets
# 

# pixel values to be between 0 and 1
# 

# In[57]:


x_train = x_train / 255.0
x_test = x_test / 255.0
plt.figure(figsize=(5,5))


# In[58]:


from tensorflow.keras import layers, models


# In[59]:


model = models.Sequential()
model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 3)))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Conv2D(64, (3, 3), activation='relu'))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Conv2D(64, (3, 3), activation='relu'))
model.add(layers.Flatten())
model.add(layers.Dense(64, activation='relu'))
model.add(layers.Dense(10))


# In[60]:


model.compile(optimizer='adam',loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True), metrics=['accuracy'])


# In[61]:


history = model.fit(x_train, y_train, epochs=10, validation_data=(x_test, y_test))


# In[43]:


test_loss, test_acc = model.evaluate(x_test, y_test)
print('Test accuracy:', test_acc)


# In[44]:


plt.plot(history.history['accuracy'], label='accuracy')
plt.plot(history.history['val_accuracy'], label='val_accuracy')
plt.xlabel(['Epoch'])
plt.ylabel(['Accuracy'])
plt.ylim([.5,1])
plt.legend(loc='lower right')


# In[49]:


import numpy as np


# In[50]:


class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer','dog', 'frog', 'horse', 'ship', 'truck']


# # Predict classes for  sample images
# 

# In[64]:


predictions = model.predict(test_images[:5])


# In[65]:


predicted_class_names = [class_names[np.argmax(prediction)] for prediction in predictions]


# In[66]:


print(predicted_class_names)


# In[67]:


class_names=['airplane','automobile','bird','cat','deer','dog','frog','horse','ship','truck']


# In[68]:


for i in range(6):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(x_train[i])
    plt.xlabel(class_names[y_train[i][0]])
    plt.show()


# In[ ]:




